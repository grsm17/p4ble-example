/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

/************function prototypes***********/

void LEDBlink(uint8 val);
void CustomEventHandler(uint32 event, void * eventParam);
void SendNotification(uint8 userData[2]);



/*******************************************************************************
* Function Name: LEDBlink
********************************************************************************
* Summary:
*        function to blink an led xx times
*
* Parameters:
*  val:	number of blinks	
*
* Return:
*  void
*
*******************************************************************************/
//function to blink an led xx times
void LEDBlink(uint8 val)
{
    uint8 i;
    for(i=0; i<val;i++) //run the cycle as many times as the valu passed in to it
    {
        RED_LED_Write(0); //turn LED on
        CyDelay(250);//delay 250ms
        RED_LED_Write(1);//turn LED off
        CyDelay(250);//delay 250ms
        CyBle_ProcessEvents();//in case we get stuck in a long loop process events to make sure we don't miss anything
    }
    
}


/**************************Variable Declarations*****************************/
/* 'connectionHandle' stores connection parameters */
CYBLE_CONN_HANDLE_T  connectionHandle;

/*This flag is set when the Central device writes to CCCD of the  enable notifications */
uint8 sendNotifications = 0;	

/* Local variable to store the current CCCD value */
uint8 NotifyCCCDvalue[2];


/* Handle value to update the CCCD */
CYBLE_GATT_HANDLE_VALUE_PAIR_T NotificationCCCDhandle;

//handles to create database arrays for the read and write data
CYBLE_GATT_HANDLE_VALUE_PAIR_T		LEDBlinkHandle;
CYBLE_GATT_HANDLE_VALUE_PAIR_T		ButtonDataHandle;

CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
CYBLE_GATTS_CHAR_VAL_READ_REQ_T  *rdReqParam;

uint8 Count=0; //variable to count the number of switch presses
uint16 DelayVal=0; //variable used to implement a delay between sending notifications
uint8 LEDBlinkData[2];//local variable to store led blink data
uint8 ButtonData[2];//local variable used to store button press data to be read
uint8 NotifyData[2];//local variable to store notifucation data



/**********main function********/

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    
    CyBle_Start(CustomEventHandler);//start the ble component and register the custom callback


    for(;;)
    {
        CyBle_ProcessEvents();   //check for any ble stack events    
        
        if(SW2_Read()==0) //read the switch and if it is pressed it will equal 0
        {   
            while(SW2_Read()==0)
            {
                CyBle_ProcessEvents();//while the switch is pressed check for stack events
            }
            Count++;//on release increment the counter
                     
        }//end if sw2 read
        
        if(sendNotifications==1)//if notifications have been enabled
        {   
            DelayVal++;//delay for a period of time 
            if(DelayVal==50000)
            {
                DelayVal=0;//reset value
                
                NotifyData[0]++;//increment a notifications counter
                NotifyData[1] = Count;//load switch press count in to second byte
                SendNotification(NotifyData);//call the function to send the notification
            }
            
        }//end if sendnotifications
        
    }//end of for
}//end of main



/*******************************************************************************
* Function Name: CustomEventHandler
********************************************************************************
* Summary:
*        Call back event function to handle varios events from BLE stack
*
* Parameters:
*  event:		event returned
*  eventParam:	link to value of the events returned
*
* Return:
*  void
*
*******************************************************************************/
void CustomEventHandler(uint32 event, void * eventParam)
{
    
    
    switch(event)
    {
        case CYBLE_EVT_STACK_ON:
			/* This event is received when component is Started */
            //funcion call to start advertsing in fast mode
			CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
			break;
       
		/**********************************************************
        *                       GAP Events
        ***********************************************************/
		  case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
			/* If the current BLE state is Disconnected, then the Advertisement
			* Start Stop event implies that advertisement has stopped */
			if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
			{
		    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);//if we stopped and we aren't connected restart advertising
			
			}
			break;
			
			case CYBLE_EVT_GAP_DEVICE_CONNECTED: 					
			/* This event is received when device is connected over GAP layer */
            
			break;
        
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
			/* This event is received when device is disconnected */
            
            /*restart advertising on disconnection*/
		    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
			break;
        
		/**********************************************************
        *                       GATT Events
        ***********************************************************/
        case CYBLE_EVT_GATT_CONNECT_IND:
			/* This event is received when device is connected over GATT level */
			/* Update attribute handle on GATT Connection*/
            connectionHandle = *(CYBLE_CONN_HANDLE_T  *)eventParam;	
			break;
        
        case CYBLE_EVT_GATT_DISCONNECT_IND:
			/* This event is received when device is disconnected */
			/* Reset  notification flag to prevent further notifications
			 * being sent to Central device after next connection. */
			sendNotifications = 0;
            NotifyData[0]=0;//reset the notification data

			/* Reset the CCCD value to disable notifications */
    		/* Write the present  notification status to the local variable */
    		NotifyCCCDvalue[0] = sendNotifications;
    		NotifyCCCDvalue[1] = 0x00;
		
    		/* Update CCCD handle with notification status data*/
    		NotificationCCCDhandle.attrHandle = CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE;
    		NotificationCCCDhandle.value.val = NotifyCCCDvalue;
    		NotificationCCCDhandle.value.len = sizeof(NotifyCCCDvalue);
    		
    		/* Report data to BLE component for sending data when read by Central device */
    		CyBle_GattsWriteAttributeValue(&NotificationCCCDhandle, 0, &connectionHandle, CYBLE_GATT_DB_PEER_INITIATED);
    					
			break;
        
            
        case CYBLE_EVT_GATTS_WRITE_REQ:
			/* This event is received when Central device sends a Write command on an Attribute */
            wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;

			/* When this event is triggered, the peripheral has received a write command on the custom characteristic */
			/* Check if command is for correct attribute and update the flag for sending Notifications */
            if(CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
				/* Extract the Write value sent by the Client for Notify CCCD */
                if(wrReqParam->handleValPair.value.val[CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX] == 1)
                {
                    sendNotifications = 1;
                }
                else if(wrReqParam->handleValPair.value.val[CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX] == 0)
                {
                    sendNotifications = 0;
                    NotifyData[0]=0;//reset the data to start at 0
                }
				
        		/* Write the present notification status to the local variable */
        		NotifyCCCDvalue[0] = sendNotifications;
        		NotifyCCCDvalue[1] = 0x00;
        		
        		/* Update CCCD handle with notification status data*/
        		NotificationCCCDhandle.attrHandle = CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE;
        		NotificationCCCDhandle.value.val = NotifyCCCDvalue;
        		NotificationCCCDhandle.value.len = sizeof(NotifyCCCDvalue);
        		
        		/* Report data to BLE component for sending data when read by Central device */
        		CyBle_GattsWriteAttributeValue(&NotificationCCCDhandle, 0, &connectionHandle, CYBLE_GATT_DB_PEER_INITIATED);
            }
            
			/* Check if the returned handle is matching to writedata Write Attribute and extract the data*/
            if(CYBLE_CUSTOM_SERVICE_LEDBLINK_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
				
                
                /* Extract the Write value sent by the Client */
                LEDBlinkData[0] = wrReqParam->handleValPair.value.val[0];
                LEDBlinkData[1] = wrReqParam->handleValPair.value.val[1];
             
				
                
                /* Update writedata handle with new values */
	            LEDBlinkHandle.attrHandle = CYBLE_CUSTOM_SERVICE_LEDBLINK_CHAR_HANDLE;
	            LEDBlinkHandle.value.val = LEDBlinkData;
	            LEDBlinkHandle.value.len = sizeof(LEDBlinkData);
	
	            /* Send updated writedata handle as attribute for read by central device */
	            CyBle_GattsWriteAttributeValue(&LEDBlinkHandle,0,&connectionHandle,0);
                
				/* Blink the Red LED the number of times equal to the value of data 0*/
                LEDBlink(LEDBlinkData[0]);
           }
			
			/* Send the response to the write request received. */
			CyBle_GattsWriteRsp(connectionHandle);
			break;
            
            
		case CYBLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ:
            /*This event is generated wehn the client requests to read data from the server*/
                rdReqParam = (CYBLE_GATTS_CHAR_VAL_READ_REQ_T *) eventParam;//copy the details
                
                /*check to see if the read is to the read data charaacteristic*/
                if(CYBLE_CUSTOM_SERVICE_BUTTONDATA_CHAR_HANDLE == rdReqParam->attrHandle)
                {
                    
                    ButtonData[0]=Count;//load the number of switch presses in to the first byte
                    ButtonData[1]++;//increment the second byte
   
                    
                    ButtonDataHandle.attrHandle = CYBLE_CUSTOM_SERVICE_BUTTONDATA_CHAR_HANDLE;//this then writes the data in to the database
                    ButtonDataHandle.value.val =  ButtonData;
                    ButtonDataHandle.value.len = sizeof(ButtonData);
                    ButtonDataHandle.value.actualLen = sizeof(ButtonData);
                  
                  /* Send updated  handle as attribute for read by central device */
                CyBle_GattsWriteAttributeValue(&ButtonDataHandle, 0, &cyBle_connHandle, 0);
                    
                }

        default:

       	 	break;
    }   	/* switch(event) */
}



/*******************************************************************************
* Function Name: SendNotification
********************************************************************************
* Summary:
*        Send data as BLE Notifications. This function updates
* the notification handle with data and triggers the BLE component to send 
* notification
*
* Parameters:
*  userData:	4bytes of data to be sent in a notification	
*
* Return:
*  void
*
*******************************************************************************/
void SendNotification(uint8 userData[2])
{
	/* 'notificationHandle' stores notification data parameters */
	CYBLE_GATTS_HANDLE_VALUE_NTF_T		NotifyHandle;	
	
	
	/* Update notification handle will CapSense slider data*/
	NotifyHandle.attrHandle = CYBLE_CUSTOM_SERVICE_NOTIFYDATA_CHAR_HANDLE;				
	NotifyHandle.value.val = userData;
	NotifyHandle.value.len = 2;

	/* Send the updated handle as part of attribute for notifications */
	CyBle_GattsNotification(connectionHandle,&NotifyHandle);

}
/* [] END OF FILE */
